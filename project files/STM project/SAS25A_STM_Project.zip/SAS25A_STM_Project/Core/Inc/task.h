/*
 * task.h
 *
 *  Created on: Mar 31, 2025
 *      Author: nassch
 */

#ifndef INC_TASK_H_
#define INC_TASK_H_

void TASK_Init();
void TASK_Emitter();
void TASK_Evolve();
void TASK_Receiver();

#endif /* INC_TASK_H_ */
