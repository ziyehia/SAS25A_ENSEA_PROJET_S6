/*
 * utils.h
 *
 *  Created on: Mar 31, 2025
 *      Author: nassch
 */

#ifndef INC_UTILS_H_
#define INC_UTILS_H_

void setup();
void loop();

#endif /* INC_UTILS_H_ */
